package com.example.rollchart_bldr

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
